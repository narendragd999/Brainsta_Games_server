import os
import uuid
import sqlite3
import json
import cv2
import numpy as np
import smtplib
import threading
import time
import qrcode
import zipfile
from io import BytesIO
from datetime import datetime, timedelta
from email.mime.text import MIMEText

from flask import Flask, render_template_string, request, jsonify, send_from_directory, redirect, url_for, session, flash, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from PIL import Image

# ==========================================
# CONFIGURATION
# ==========================================
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

# Folders
MEDIA_FOLDER = os.path.join(APP_ROOT, 'snapmatch_uploads')
SELFIES_FOLDER = os.path.join(APP_ROOT, 'snapmatch_selfies')
QR_FOLDER = os.path.join(APP_ROOT, 'static_qr') 
DATABASE = os.path.join(APP_ROOT, 'snap_pro.db')

# AI SETTINGS
DISTANCE_THRESHOLD = 0.70
MODEL_NAME = 'ArcFace' 
DEBUG_MODE = True

# PAYMENT SETTINGS
UPI_ID = "veer@upi" 
PAYMENT_NOTE = "SnapMatch Event Access"

# EMAIL SETTINGS
ENABLE_EMAIL_SENDING = False
MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
MAIL_PORT = 587
MAIL_USERNAME = os.getenv('MAIL_USERNAME', 'your_email@gmail.com')
MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', 'your_password')

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024 * 1024 * 2  # 2GB
app.secret_key = os.getenv('SECRET_KEY', 'super_secret_pro_v5')

# Ensure folders exist
for folder in [MEDIA_FOLDER, SELFIES_FOLDER, QR_FOLDER]:
    os.makedirs(folder, exist_ok=True)

print(f"[CONFIG] Media Folder: {os.path.abspath(MEDIA_FOLDER)}")

# ==========================================
# DATABASE SCHEMA
# ==========================================
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE NOT NULL,
                 email TEXT UNIQUE NOT NULL,
                 password TEXT NOT NULL,
                 is_verified INTEGER DEFAULT 0,
                 is_admin INTEGER DEFAULT 0,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    c.execute('''CREATE TABLE IF NOT EXISTS events (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 user_id INTEGER NOT NULL,
                 share_token TEXT UNIQUE NOT NULL,
                 keep_days INTEGER NOT NULL,
                 is_paid INTEGER DEFAULT 0,
                 payment_amount REAL DEFAULT 0.0,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY(user_id) REFERENCES users(id))''')
    
    c.execute("CREATE INDEX IF NOT EXISTS idx_events_user ON events(user_id)")

    c.execute('''CREATE TABLE IF NOT EXISTS media (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 event_id INTEGER NOT NULL,
                 filename TEXT NOT NULL,
                 file_type TEXT NOT NULL,
                 embeddings_json TEXT,
                 expiry_date TIMESTAMP NOT NULL,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE)''')
    
    c.execute("CREATE INDEX IF NOT EXISTS idx_media_expiry ON media(expiry_date)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_media_event ON media(event_id)")

    conn.commit()
    conn.close()
    print("[DB] Database initialized.")

# ==========================================
# BACKGROUND WORKER
# ==========================================
def cleanup_worker():
    while True:
        try:
            conn = get_db_connection()
            now = datetime.now()
            expired = conn.execute("SELECT id, filename FROM media WHERE expiry_date < ?", (now,)).fetchall()
            for item in expired:
                file_path = os.path.join(MEDIA_FOLDER, item['filename'])
                try:
                    if os.path.exists(file_path): os.remove(file_path)
                    conn.execute("DELETE FROM media WHERE id = ?", (item['id'],))
                except: pass
            conn.commit()
            conn.close()
        except: pass
        time.sleep(3600)

threading.Thread(target=cleanup_worker, daemon=True).start()

# ==========================================
# HELPERS
# ==========================================
def generate_upi_qr(amount, note):
    upi_string = f"upi://pay?pa={UPI_ID}&pn=SnapMatch&am={amount}&tn={note}"
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(upi_string)
    qr.make(fit=True)
    img = qr.make_image(fill='black', back='white')
    filename = f"qr_{uuid.uuid4()}.png"
    img.save(os.path.join(QR_FOLDER, filename))
    return filename

def login_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session: return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

def admin_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_admin'):
            flash("Admin access only.", "error")
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# ==========================================
# PROFESSIONAL HTML TEMPLATE
# ==========================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SnapMatch | AI Photo Finder</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4F46E5; /* Indigo 600 */
            --primary-hover: #4338ca;
            --secondary: #10B981; /* Emerald 500 */
            --bg-body: #F3F4F6;
            --surface: #ffffff;
            --text-main: #111827;
            --text-muted: #6B7280;
            --danger: #EF4444;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius: 16px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-body); color: var(--text-main); min-height: 100vh; display: flex; flex-direction: column; }
        
        /* Navbar */
        nav { background: var(--surface); padding: 1rem 2rem; box-shadow: var(--shadow-sm); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
        .logo { font-weight: 700; font-size: 1.5rem; color: var(--primary); text-decoration: none; letter-spacing: -0.025em; }
        .nav-links { display: flex; gap: 1.5rem; }
        .nav-links a { text-decoration: none; color: var(--text-muted); font-weight: 500; font-size: 0.95rem; transition: color 0.2s; }
        .nav-links a:hover { color: var(--primary); }

        /* Layout */
        .container { max-width: 1100px; margin: 0 auto; padding: 2rem 1rem; width: 100%; flex: 1; }

        /* Cards */
        .card { background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow-md); padding: 2rem; margin-bottom: 2rem; transition: transform 0.2s ease, box-shadow 0.2s ease; border: 1px solid rgba(0,0,0,0.02); }
        .card:hover { box-shadow: var(--shadow-lg); transform: translateY(-2px); }
        
        h2 { font-size: 1.875rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main); }
        p.subtitle { color: var(--text-muted); margin-bottom: 2rem; line-height: 1.6; }

        /* Inputs */
        .input-group { margin-bottom: 1.5rem; position: relative; }
        input, select { width: 100%; padding: 0.875rem 1rem; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 1rem; font-family: inherit; transition: border-color 0.2s; background: #F9FAFB; }
        input:focus, select:focus { outline: none; border-color: var(--primary); background: white; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        /* Buttons */
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; font-size: 0.95rem; text-decoration: none; cursor: pointer; transition: all 0.2s; border: none; font-family: inherit; }
        .btn-primary { background: var(--primary); color: white; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.3); }
        .btn-primary:hover { background: var(--primary-hover); transform: translateY(-1px); }
        .btn-outline { background: transparent; border: 2px solid var(--primary); color: var(--primary); }
        .btn-outline:hover { background: rgba(79, 70, 229, 0.05); }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #DC2626; }
        .btn-full { width: 100%; }

        /* Table */
        .table-container { overflow-x: auto; border: 1px solid #E5E7EB; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th { text-align: left; padding: 1rem; background: #F9FAFB; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 600; }
        td { padding: 1rem; border-bottom: 1px solid #E5E7EB; font-size: 0.95rem; }
        tr:last-child td { border-bottom: none; }

        /* Upload Zone */
        .upload-zone { border: 2px dashed #D1D5DB; border-radius: 12px; padding: 3rem; text-align: center; cursor: pointer; transition: 0.3s; background: #F9FAFB; position: relative; }
        .upload-zone:hover { border-color: var(--primary); background: #EEF2FF; }
        .upload-zone input { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
        .upload-icon { font-size: 3rem; margin-bottom: 1rem; display: block; }

        /* Camera & Results Page (Professional) */
        .hero-section { text-align: center; max-width: 600px; margin: 0 auto; }
        
        .camera-wrapper { position: relative; width: 280px; height: 280px; margin: 2rem auto; border-radius: 50%; overflow: hidden; border: 4px solid white; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); background: #000; }
        video { width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); }
        
        .btn-snap { 
            width: 72px; height: 72px; border-radius: 50%; background: white; border: 4px solid var(--primary); 
            position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: transform 0.1s;
        }
        .btn-snap:active { transform: translateX(-50%) scale(0.95); }
        .btn-snap::after {
            content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
            width: 60px; height: 60px; border-radius: 50%; background: white; opacity: 0.5;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: translate(-50%, -50%) scale(1); opacity: 0.8; }
            70% { transform: translate(-50%, -50%) scale(1.3); opacity: 0; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 0; }
        }

        /* Results Grid */
        .gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1.5rem; margin-top: 2rem; }
        .photo-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: var(--shadow-sm); transition: transform 0.3s; position: relative; group: hover; }
        .photo-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); }
        .photo-card img { width: 100%; height: 220px; object-fit: cover; display: block; }
        .photo-actions { 
            padding: 1rem; display: flex; justify-content: space-between; align-items: center; 
            background: white; border-top: 1px solid #F3F4F6;
        }
        .photo-actions a { text-decoration: none; color: var(--primary); font-weight: 600; font-size: 0.9rem; }

        /* Alerts */
        .alert { padding: 1rem 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; display: flex; align-items: center; font-weight: 500; }
        .alert-success { background: #ECFDF5; color: #065F46; border: 1px solid #A7F3D0; }
        .alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }

        /* Chips */
        .chip { display: inline-flex; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
        .chip-active { background: #D1FAE5; color: #065F46; }
        .chip-inactive { background: #FEE2E2; color: #991B1B; }

        /* Download All Floating Button (Optional) or Inline */
        .download-all-container { margin-top: 1rem; text-align: center; display: none; }
        .download-all-container.show { display: block; animation: slideDown 0.5s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

    </style>
</head>
<body>

<nav>
    <a href="/" class="logo">SnapMatch</a>
    <div class="nav-links">
        {% if session.get('user_id') %}
            <a href="/dashboard">Dashboard</a>
            <a href="/events">My Events</a>
            {% if session.get('is_admin') %}<a href="/admin/users">Admin</a>{% endif %}
            <a href="/logout" style="color: var(--danger)">Logout</a>
        {% else %}
            <a href="/login">Login</a>
            <a href="/register" style="color: var(--primary); font-weight: 700;">Get Started</a>
        {% endif %}
    </div>
</nav>

<div class="container">
    {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
                <div class="alert alert-{{ 'error' if category == 'error' else 'success' }}">
                    {{ message }}
                </div>
            {% endfor %}
        {% endif %}
    {% endwith %}

    <!-- LOGIN -->
    {% if view == 'login' %}
    <div class="card" style="max-width: 420px; margin: 3rem auto;">
        <h2 style="text-align:center;">Welcome Back</h2>
        <p class="subtitle" style="text-align:center;">Enter your details to access your events</p>
        <form method="post">
            <div class="input-group">
                <input type="text" name="login" placeholder="Username or Email" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Login</button>
            <p style="text-align:center; margin-top:1.5rem; font-size:0.9rem;">
                Don't have an account? <a href="/register" style="color:var(--primary)">Register</a>
            </p>
        </form>
    </div>
    {% endif %}

    <!-- REGISTER -->
    {% if view == 'register' %}
    <div class="card" style="max-width: 420px; margin: 3rem auto;">
        <h2 style="text-align:center;">Create Account</h2>
        <p class="subtitle" style="text-align:center;">Start finding your photos instantly</p>
        <form method="post">
            <div class="input-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <input type="email" name="email" placeholder="Email Address" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Create Account</button>
        </form>
    </div>
    {% endif %}

    <!-- DASHBOARD -->
    {% if view == 'dashboard' %}
    <div class="card">
        <h2>Hello, {{ session.username }} 👋</h2>
        <p class="subtitle">Manage your photography events and access AI-powered photo galleries.</p>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
            <a href="/events/create" class="card" style="text-align:center; padding: 1.5rem; text-decoration:none; color:inherit; border: 1px dashed var(--primary); background: #EEF2FF;">
                <div style="font-size:2rem; margin-bottom:0.5rem;">+</div>
                <div style="font-weight:600;">Create New Event</div>
            </a>
            <a href="/events" class="card" style="text-align:center; padding: 1.5rem; text-decoration:none; color:inherit; border: 1px solid #E5E7EB;">
                <div style="font-size:2rem; margin-bottom:0.5rem;">📂</div>
                <div style="font-weight:600;">My Events</div>
            </a>
        </div>
    </div>
    {% endif %}

    <!-- EVENTS LIST -->
    {% if view == 'events' %}
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem;">
        <h2>My Events</h2>
        <a href="/events/create" class="btn btn-primary">+ Create Event</a>
    </div>
    <div class="card" style="padding:0;">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Retention</th>
                        <th>Status</th>
                        <th style="text-align:right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {% for e in events %}
                    <tr>
                        <td>
                            <div style="font-weight:600;">{{ e.name }}</div>
                            <div style="font-size:0.8rem; color:var(--text-muted)">Code: {{ e.share_token }}</div>
                        </td>
                        <td>{{ e.keep_days }} Days</td>
                        <td>
                            {% if e.is_paid %}
                                <span class="chip chip-active">Active</span>
                            {% else %}
                                <span class="chip chip-inactive">Payment Pending</span>
                            {% endif %}
                        </td>
                        <td style="text-align:right">
                            {% if e.is_paid %}
                                <a href="/event/{{ e.id }}/upload" class="btn btn-outline" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Upload</a>
                            {% else %}
                                <a href="/event/{{ e.id }}/pay" class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Pay ₹{{ e.payment_amount }}</a>
                            {% endif %}
                            <a href="/share/{{ e.share_token }}" target="_blank" class="btn btn-outline" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Share</a>
                            <form action="/event/{{ e.id }}/delete" method="post" onsubmit="return confirm('Delete this event?');" style="display:inline;">
                                <button class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Delete</button>
                            </form>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
    {% endif %}

    <!-- CREATE EVENT -->
    {% if view == 'create_event' %}
    <div class="card" style="max-width: 500px; margin: 0 auto;">
        <h2>Create Event</h2>
        <p class="subtitle">Setup a new gallery for your photos.</p>
        <form method="post">
            <div class="input-group">
                <label style="display:block; margin-bottom:0.5rem; font-weight:600; font-size:0.9rem;">Event Name</label>
                <input type="text" name="name" placeholder="e.g. Annual Gala 2024" required>
            </div>
            <div class="input-group">
                <label style="display:block; margin-bottom:0.5rem; font-weight:600; font-size:0.9rem;">Retention Period</label>
                <select name="keep_days" required onchange="updatePrice()">
                    <option value="1">1 Day (Free)</option>
                    <option value="2">2 Days (Free)</option>
                    <option value="3">3 Days (Free)</option>
                    <option value="7">7 Days (₹99)</option>
                    <option value="30">30 Days (₹299)</option>
                </select>
            </div>
            <div id="priceBox" style="background: #F3F4F6; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; text-align:center; font-weight:700; color: var(--primary);">
                Total: Free
            </div>
            <button type="submit" class="btn btn-primary btn-full">Create Event</button>
        </form>
    </div>
    <script>
        function updatePrice(){
            const val = document.querySelector('select[name="keep_days"]').value;
            const cost = val > 3 ? (val == 7 ? 99 : 299) : 0;
            document.getElementById('priceBox').innerText = cost > 0 ? `Total: ₹${cost}` : "Total: Free";
        }
    </script>
    {% endif %}

    <!-- UPLOAD -->
    {% if view == 'upload' %}
    <div class="card">
        <h2>Upload Media</h2>
        <p class="subtitle">Event: <strong>{{ event.name }}</strong> • Files will be auto-deleted after {{ event.keep_days }} days.</p>
        
        <form method="post" enctype="multipart/form-data">
            <div class="upload-zone" id="dropZone">
                <input type="file" name="media" id="fileInput" multiple required onchange="handleFiles(this.files)">
                <span class="upload-icon">☁️</span>
                <h3 style="margin:0 0 0.5rem 0;">Click to upload or drag & drop</h3>
                <p style="color:var(--text-muted); font-size:0.9rem;">SVG, PNG, JPG or GIF (max. 2GB)</p>
                <div id="fileList" style="margin-top:1rem; font-weight:600; color:var(--primary);"></div>
            </div>
            <button type="submit" class="btn btn-primary btn-full" style="margin-top:1.5rem;">Start Upload</button>
        </form>
    </div>
    <script>
        function handleFiles(files) {
            document.getElementById('fileList').innerText = files.length > 0 ? `${files.length} files selected` : '';
        }
        const dz = document.getElementById('dropZone');
        dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.style.borderColor = 'var(--primary)'; });
        dz.addEventListener('dragleave', (e) => { e.preventDefault(); dz.style.borderColor = '#D1D5DB'; });
        dz.addEventListener('drop', (e) => { 
            e.preventDefault(); 
            dz.style.borderColor = '#D1D5DB';
            document.getElementById('fileInput').files = e.dataTransfer.files;
            handleFiles(e.dataTransfer.files);
        });
    </script>
    {% endif %}

    <!-- PAYMENT -->
    {% if view == 'payment' %}
    <div class="card" style="max-width:400px; margin:0 auto; text-align:center;">
        <h2>Secure Payment</h2>
        <p class="subtitle">Scan QR Code to pay <strong>₹{{ event.payment_amount }}</strong></p>
        <div style="margin: 2rem 0; display:inline-block; padding:1rem; background:white; border-radius:12px; box-shadow:var(--shadow-sm);">
            <img src="/static_qr/{{ qr_file }}" style="width:200px; display:block;">
        </div>
        <p style="font-weight:600;">UPI ID: <span style="color:var(--primary)">{{ UPI_ID }}</span></p>
        <form method="post" style="margin-top:2rem;">
            <button type="submit" class="btn btn-primary btn-full">Confirm Payment</button>
        </form>
    </div>
    {% endif %}

    <!-- PUBLIC SHARE (THE HERO PAGE) -->
    {% if view == 'share' %}
    <div class="hero-section">
        <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem;">Find Your Photos</h1>
        <p class="subtitle">Take a selfie to discover your photos from <strong>{{ event.name }}</strong>.</p>
        
        <div class="camera-wrapper">
            <video id="video" autoplay playsinline muted></video>
            <div class="btn-snap" onclick="snapAndMatch()"></div>
        </div>
        
        <div id="status" style="min-height:24px; font-weight:600; color:var(--text-muted); margin-top:1rem;"></div>

        <!-- DOWNLOAD ALL BUTTON -->
        <div id="downloadAllContainer" class="download-all-container">
            <button onclick="downloadAll()" class="btn btn-primary" style="padding: 1rem 2rem; font-size: 1.1rem; box-shadow: var(--shadow-lg);">
                ⬇️ Download All Photos
            </button>
        </div>

        <div id="results" class="gallery-grid"></div>
    </div>
    <script>
        const video = document.getElementById('video');
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } }).then(s => video.srcObject = s).catch(e => alert("Please allow camera access."));

        let matchedFiles = [];

        function snapAndMatch() {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth; canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            
            canvas.toBlob(blob => {
                const fd = new FormData(); fd.append('selfie', blob);
                const status = document.getElementById('status');
                status.innerHTML = '<span style="color:var(--primary)">🔍 Analyzing face...</span>';
                
                fetch('/match/{{ token }}', { method: 'POST', body: fd })
                .then(r => r.json())
                .then(d => {
                    const res = document.getElementById('results');
                    const dlBtn = document.getElementById('downloadAllContainer');
                    res.innerHTML = '';
                    matchedFiles = d.matches; // Store for download all
                    
                    if(d.matches.length > 0) {
                        d.matches.forEach(m => {
                            res.innerHTML += `
                            <div class="photo-card">
                                <img src="/uploads/${m}" loading="lazy">
                                <div class="photo-actions">
                                    <span>HD Photo</span>
                                    <a href="/uploads/${m}" download>Download</a>
                                </div>
                            </div>`;
                        });
                        status.innerHTML = `<span style="color:var(--secondary)">✅ Found ${d.matches.length} photos!</span>`;
                        dlBtn.classList.add('show');
                    } else {
                        status.innerHTML = `<span style="color:var(--danger)">❌ No matches found. Try again.</span>`;
                        dlBtn.classList.remove('show');
                    }
                });
            }, 'image/jpeg');
        }

        function downloadAll() {
            if (matchedFiles.length === 0) return;
            
            const btn = document.querySelector('#downloadAllContainer button');
            const originalText = btn.innerText;
            btn.innerText = "Zipping...";
            btn.disabled = true;

            fetch('/download_all', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filenames: matchedFiles })
            })
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = 'my_photos.zip';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                
                btn.innerText = originalText;
                btn.disabled = false;
            })
            .catch(error => {
                console.error('Error:', error);
                btn.innerText = "Error. Try again.";
                btn.disabled = false;
            });
        }
    </script>
    {% endif %}

    <!-- ADMIN USERS -->
    {% if view == 'admin_users' %}
    <div class="card">
        <h2>User Management</h2>
        <form method="post" style="display:grid; grid-template-columns: 2fr 2fr 1fr auto; gap:1rem; margin-bottom:2rem;">
            <input name="username" placeholder="Username" required style="margin:0">
            <input name="email" placeholder="Email" required style="margin:0">
            <input name="password" placeholder="Password" required style="margin:0">
            <button type="submit" class="btn btn-primary" style="height: 46px;">Add</button>
        </form>
        <div class="table-container">
            <table>
                <thead><tr><th>User</th><th>Email</th><th>Admin</th><th>Action</th></tr></thead>
                <tbody>
                    {% for u in users %}
                    <tr>
                        <td>{{ u.username }}</td>
                        <td>{{ u.email }}</td>
                        <td>{{ 'Yes' if u.is_admin else 'No' }}</td>
                        <td>
                            <a href="/admin/users/{{ u.id }}/edit" class="btn btn-outline" style="padding:0.25rem 0.75rem; font-size:0.8rem;">Edit</a>
                            <form action="/admin/users/{{ u.id }}/delete" method="post" style="display:inline" onsubmit="return confirm('Delete?')">
                                <button class="btn btn-danger" style="padding:0.25rem 0.75rem; font-size:0.8rem;">Del</button>
                            </form>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
    {% endif %}

    <!-- EDIT USER -->
    {% if view == 'edit_user' %}
    <div class="card" style="max-width:400px; margin:0 auto;">
        <h2>Edit User</h2>
        <form method="post">
            <div class="input-group"><input type="text" name="username" value="{{ user.username }}" required><label>Username</label></div>
            <div class="input-group"><input type="email" name="email" value="{{ user.email }}" required><label>Email</label></div>
            <div class="input-group"><input type="password" name="password" placeholder="New Password (optional)"></div>
            <div class="input-group">
                <select name="is_admin" required>
                    <option value="0" {% if not user.is_admin %}selected{% endif %}>User</option>
                    <option value="1" {% if user.is_admin %}selected{% endif %}>Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Update User</button>
        </form>
    </div>
    {% endif %}

</div>
</body>
</html>
"""

# ==========================================
# ROUTES
# ==========================================

@app.route('/')
def index():
    if 'user_id' in session: return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            h = generate_password_hash(request.form['password'])
            conn = get_db_connection()
            conn.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                         (request.form['username'], request.form['email'], h))
            conn.commit()
            conn.close()
            flash("Account created! Please login.", "success")
            return redirect(url_for('login'))
        except: flash("Username or Email already exists.", "error")
    return render_template_string(HTML_TEMPLATE, view='register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        conn = get_db_connection()
        u = conn.execute("SELECT * FROM users WHERE username=? OR email=?", 
                         (request.form['login'], request.form['login'])).fetchone()
        conn.close()
        if u and check_password_hash(u['password'], request.form['password']):
            session['user_id'] = u['id']
            session['username'] = u['username']
            session['is_admin'] = u['is_admin']
            return redirect(url_for('dashboard'))
        flash("Invalid credentials.", "error")
    return render_template_string(HTML_TEMPLATE, view='login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template_string(HTML_TEMPLATE, view='dashboard')

# --- EVENT MANAGEMENT ---

@app.route('/events')
@login_required
def events():
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE user_id=? ORDER BY id DESC", (session['user_id'],)).fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='events', events=ev)

@app.route('/events/create', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        name = request.form['name']
        days = int(request.form['keep_days'])
        is_paid = 0
        amount = 0.0
        if days > 3:
            is_paid = 0
            amount = 99.0 if days == 7 else 299.0
        else:
            is_paid = 1
            
        token = str(uuid.uuid4())[:8]
        conn = get_db_connection()
        conn.execute("INSERT INTO events (name, user_id, share_token, keep_days, is_paid, payment_amount) VALUES (?,?,?,?,?,?)",
                     (name, session['user_id'], token, days, is_paid, amount))
        conn.commit()
        conn.close()
        return redirect(url_for('events'))
    return render_template_string(HTML_TEMPLATE, view='create_event')

@app.route('/event/<int:eid>/delete', methods=['POST'])
@login_required
def delete_event(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    if ev and ev['user_id'] == session['user_id']:
        media = conn.execute("SELECT filename FROM media WHERE event_id=?", (eid,)).fetchall()
        for m in media:
            try: os.remove(os.path.join(MEDIA_FOLDER, m['filename']))
            except: pass
        conn.execute("DELETE FROM media WHERE event_id=?", (eid,))
        conn.execute("DELETE FROM events WHERE id=?", (eid,))
        conn.commit()
        flash("Event deleted.", "success")
    conn.close()
    return redirect(url_for('events'))

@app.route('/event/<int:eid>/pay', methods=['GET', 'POST'])
@login_required
def pay_event(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    if not ev: return redirect(url_for('events'))
    if request.method == 'POST':
        conn.execute("UPDATE events SET is_paid=1 WHERE id=?", (eid,))
        conn.commit()
        flash("Payment verified!", "success")
        conn.close()
        return redirect(url_for('events'))
    qr_file = generate_upi_qr(ev['payment_amount'], f"Event {ev['id']}")
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='payment', event=ev, qr_file=qr_file, UPI_ID=UPI_ID)

@app.route('/event/<int:eid>/upload', methods=['GET', 'POST'])
@login_required
def upload_media(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    
    if not ev or ev['user_id'] != session['user_id'] or ev['is_paid'] == 0:
        conn.close()
        return redirect(url_for('events'))

    if request.method == 'POST':
        files = request.files.getlist('media')
        expiry = datetime.now() + timedelta(days=ev['keep_days'])
        count = 0
        
        for f in files:
            if f.filename: 
                fname = f"{uuid.uuid4()}_{secure_filename(f.filename)}"
                path = os.path.join(MEDIA_FOLDER, fname)
                try:
                    f.save(path)
                    print(f"[UPLOAD] Saved: {os.path.abspath(path)}")
                    conn.execute("INSERT INTO media (event_id, filename, file_type, expiry_date) VALUES (?,?,?,?)",
                                 (eid, fname, 'image', expiry))
                    count += 1
                except Exception as e: print(e)
        
        conn.commit()
        conn.close()
        flash(f"{count} files uploaded successfully!", "success")
        return redirect(url_for('events'))
        
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='upload', event=ev)

# --- PUBLIC SHARING & AI ---

@app.route('/share/<token>')
def public_share(token):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE share_token=?", (token,)).fetchone()
    conn.close()
    if not ev: return "Invalid Link", 404
    return render_template_string(HTML_TEMPLATE, view='share', event=ev, token=token)

@app.route('/match/<token>', methods=['POST'])
def match_photos(token):
    conn = get_db_connection()
    ev = conn.execute("SELECT id FROM events WHERE share_token=?", (token,)).fetchone()
    if not ev: 
        conn.close()
        return jsonify(matches=[])
    
    selfie = request.files['selfie']
    tmp_path = os.path.join(SELFIES_FOLDER, f"temp_{uuid.uuid4()}.jpg")
    selfie.save(tmp_path)
    
    target_embedding = None
    try:
        from deepface import DeepFace
        selfie_objs = DeepFace.represent(img_path=tmp_path, model_name=MODEL_NAME, enforce_detection=False)
        if not selfie_objs: 
            if os.path.exists(tmp_path): os.remove(tmp_path)
            conn.close()
            return jsonify(matches=[])
        target_embedding = selfie_objs[0]["embedding"]
    except Exception as e:
        print(f"[AI] Error: {e}")
        if os.path.exists(tmp_path): os.remove(tmp_path)
        conn.close()
        return jsonify(matches=[])
    finally:
        if os.path.exists(tmp_path): os.remove(tmp_path)

    media = conn.execute("SELECT id, filename, embeddings_json FROM media WHERE event_id=?", (ev['id'],)).fetchall()
    matches = []
    
    for m in media:
        embeddings = []
        if m['embeddings_json']:
            embeddings = json.loads(m['embeddings_json'])
        else:
            try:
                file_path = os.path.join(MEDIA_FOLDER, m['filename'])
                objs = DeepFace.represent(img_path=file_path, model_name=MODEL_NAME, enforce_detection=False)
                new_embeddings = [o["embedding"] for o in objs]
                conn.execute("UPDATE media SET embeddings_json=? WHERE id=?", (json.dumps(new_embeddings), m['id']))
                conn.commit()
                embeddings = new_embeddings
            except: continue

        for emb in embeddings:
            dot = np.dot(target_embedding, emb)
            norm = np.linalg.norm(target_embedding) * np.linalg.norm(emb)
            similarity = dot / norm if norm > 0 else 0
            distance = 1 - similarity
            
            if distance < DISTANCE_THRESHOLD:
                if m['filename'] not in matches:
                    matches.append(m['filename'])
                break 
    
    conn.close()
    return jsonify(matches=matches)

# --- DOWNLOAD ALL FEATURE ---
@app.route('/download_all', methods=['POST'])
def download_all():
    data = request.json
    filenames = data.get('filenames', [])
    
    if not filenames:
        return jsonify({"error": "No files"}), 400

    # Create a zip file in memory
    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for filename in filenames:
            file_path = os.path.join(MEDIA_FOLDER, filename)
            if os.path.exists(file_path):
                # Add file to zip
                zf.write(file_path, filename)
    
    memory_file.seek(0)
    return send_file(
        memory_file,
        mimetype='application/zip',
        as_attachment=True,
        download_name='my_photos.zip'
    )

# --- USER ADMIN ---

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    conn = get_db_connection()
    users = conn.execute("SELECT * FROM users").fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='admin_users', users=users)

@app.route('/admin/users/add', methods=['POST'])
@login_required
@admin_required
def add_user():
    try:
        h = generate_password_hash(request.form['password'])
        conn = get_db_connection()
        conn.execute("INSERT INTO users (username, email, password) VALUES (?,?,?)",
                     (request.form['username'], request.form['email'], h))
        conn.commit()
        conn.close()
    except: pass
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:uid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(uid):
    if uid == session['user_id']: return redirect(url_for('admin_users'))
    conn = get_db_connection()
    conn.execute("DELETE FROM users WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:uid>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(uid):
    conn = get_db_connection()
    u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    
    if request.method == 'POST':
        pwd = request.form['password']
        update_q = "UPDATE users SET username=?, email=?, is_admin=?"
        params = [request.form['username'], request.form['email'], int(request.form['is_admin'])]
        if pwd:
            update_q += ", password=?"
            params.append(generate_password_hash(pwd))
        params.append(uid)
        conn.execute(update_q + " WHERE id=?", params)
        conn.commit()
        conn.close()
        return redirect(url_for('admin_users'))
        
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='edit_user', user=u)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(MEDIA_FOLDER, filename)

@app.route('/static_qr/<filename>')
def qr_file(filename):
    return send_from_directory(QR_FOLDER, filename)

if __name__ == '__main__':
    init_db()
    conn = get_db_connection()
    admin = conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
    if not admin:
        conn.execute("INSERT INTO users (username, email, password, is_admin) VALUES (?,?,?,1)",
                     ('admin', 'admin@snap.com', generate_password_hash('admin')))
        conn.commit()
        print("[INIT] Created admin: admin / admin")
    conn.close()
    
    print("[SERVER] Running on http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)