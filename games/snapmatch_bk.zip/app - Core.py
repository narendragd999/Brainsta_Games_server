import os
import uuid
import sqlite3
import json
import cv2
import numpy as np
import smtplib
from email.mime.text import MIMEText
from io import BytesIO
from flask import Flask, render_template_string, request, jsonify, send_from_directory, redirect, url_for, send_file, session, flash, abort
from deepface import DeepFace
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import zipfile

# ==========================================
# CONFIGURATION
# ==========================================
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
MEDIA_FOLDER = os.path.join(APP_ROOT, 'media')
UPLOAD_FOLDER = os.path.join(MEDIA_FOLDER, 'uploads')
SELFIES_FOLDER = os.path.join(MEDIA_FOLDER, 'selfies')
DATABASE = os.path.join(APP_ROOT, 'snap_verified.db')

# AI SETTINGS (UNTOUCHED MATCH LOGIC)
MODEL_NAME = 'ArcFace'
DISTANCE_THRESHOLD = 0.55 
DEBUG_MODE = True # Prints Face Matching logs
MAX_WIDTH = 800

# EMAIL SETTINGS
# Set to True when you are ready to send real emails via SMTP (e.g., Gmail)
# Set to False to print the verification link to your TERMINAL for testing
ENABLE_EMAIL_SENDING = False 
MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USERNAME = 'your_email@gmail.com' # CHANGE THIS
MAIL_PASSWORD = 'your_app_password'  # CHANGE THIS (Use App Password)

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024 * 1024  # 1GB
app.secret_key = 'snap_secure_verified_v1'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(SELFIES_FOLDER, exist_ok=True)

# ==========================================
# DATABASE (UPDATED FOR EMAIL/VERIFICATION)
# ==========================================
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    # Updated User Table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE NOT NULL,
                 email TEXT UNIQUE NOT NULL,
                 password TEXT NOT NULL,
                 is_verified INTEGER DEFAULT 0,
                 verification_token TEXT)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS photos (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 filename TEXT NOT NULL,
                 user_id INTEGER,
                 embeddings_json TEXT, 
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

init_db()

# ==========================================
# EMAIL HELPER
# ==========================================
def send_verification_email(email, username, token):
    verification_link = f"http://127.0.0.1:5000/verify/{token}"
    
    if ENABLE_EMAIL_SENDING:
        # Real SMTP Send
        msg = MIMEText(f"Hello {username},\n\nPlease verify your account by clicking the link below:\n\n{verification_link}")
        msg['Subject'] = 'Verify Your SnapMatch Account'
        msg['From'] = MAIL_USERNAME
        msg['To'] = email
        
        try:
            server = smtplib.SMTP(MAIL_SERVER, MAIL_PORT)
            server.starttls()
            server.login(MAIL_USERNAME, MAIL_PASSWORD)
            server.send_message(msg)
            server.quit()
        except Exception as e:
            print(f"[EMAIL ERROR] Failed to send email: {e}")
    else:
        # DEV MODE: Print to Terminal
        print("\n" + "="*50)
        print(f"[DEV MODE] EMAIL VERIFICATION LINK FOR {username} ({email}):")
        print(f"   {verification_link}")
        print("="*50 + "\n")

# ==========================================
# AI FUNCTIONS (UNTOUCHED)
# ==========================================

def optimize_and_save_image(file, folder, filename):
    file_path = os.path.join(folder, filename)
    file_bytes = file.read()
    nparr = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None: return None
    h, w = img.shape[:2]
    if w > MAX_WIDTH:
        ratio = MAX_WIDTH / w
        new_h = int(h * ratio)
        img = cv2.resize(img, (MAX_WIDTH, new_h), interpolation=cv2.INTER_AREA)
    cv2.imwrite(file_path, img, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    return file_path

def get_embedding(image_path):
    try:
        embeddings_objs = DeepFace.represent(img_path=image_path, model_name=MODEL_NAME, enforce_detection=False)
        if not embeddings_objs: return None
        return [obj["embedding"] for obj in embeddings_objs]
    except Exception as e:
        if DEBUG_MODE: print(f"[AI Error] {e}")
        return None

def calculate_cosine_distance(embedding1, embedding2):
    if embedding1 is None or embedding2 is None: return 1.0
    a = np.array(embedding1); b = np.array(embedding2)
    dot = np.dot(a, b); norm = np.linalg.norm(a) * np.linalg.norm(b)
    if norm == 0: return 1.0
    return 1 - (dot / norm)

def login_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session: return redirect(url_for('login'))
        # Double check verification
        conn = get_db_connection()
        user = conn.execute("SELECT is_verified FROM users WHERE id = ?", (session['user_id'],)).fetchone()
        conn.close()
        if not user or user['is_verified'] == 0:
            session.clear()
            flash("Account not verified. Please verify your email.")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# ==========================================
# HTML TEMPLATE (UPDATED FOR EMAIL)
# ==========================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SnapMatch Pro | Verified</title>
    <style>
        :root {
            --primary: #7F00FF; --secondary: #E100FF;
            --bg: #0a0a12; --card-bg: rgba(20, 20, 35, 0.8);
            --text: #ffffff; --text-muted: #a0a0b0;
            --glass-border: 1px solid rgba(255, 255, 255, 0.1);
            --danger: #ff4757; --success: #2ed573;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
        
        body {
            background-color: var(--bg);
            background-image: radial-gradient(circle at 10% 20%, rgba(127, 0, 255, 0.2) 0%, transparent 20%),
                              radial-gradient(circle at 90% 80%, rgba(225, 0, 255, 0.2) 0%, transparent 20%);
            color: var(--text); min-height: 100vh; padding-bottom: 50px;
        }
        nav { display: flex; justify-content: space-between; align-items: center; padding: 20px 40px; max-width: 1000px; margin: 0 auto; }
        .nav-brand { font-size: 1.5rem; font-weight: 800; background: linear-gradient(to right, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; cursor: pointer; }
        .nav-links a { color: var(--text); text-decoration: none; margin-left: 20px; font-weight: 500; transition: 0.3s; text-transform: uppercase; font-size: 0.8rem; }
        .nav-links a:hover { color: var(--secondary); }
        
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .card { background: var(--card-bg); backdrop-filter: blur(16px); border-radius: 20px; padding: 40px; margin-bottom: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.4); border: var(--glass-border); animation: fadeIn 0.6s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        h2 { margin-bottom: 20px; font-weight: 300; letter-spacing: 1px; }
        .tagline { color: var(--text-muted); margin-bottom: 30px; line-height: 1.6; }

        input[type="text"], input[type="password"], input[type="file"], input[type="email"] {
            width: 100%; padding: 15px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; color: white; outline: none; margin-bottom: 20px; font-size: 1rem;
        }
        .btn { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; border: none; padding: 15px 40px; border-radius: 50px; font-size: 1rem; font-weight: 700; cursor: pointer; transition: 0.3s; width: 100%; text-decoration: none; display: inline-block; text-align: center; box-shadow: 0 10px 20px rgba(127, 0, 255, 0.3); }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 15px 30px rgba(127, 0, 255, 0.5); }
        .btn-outline { background: transparent; border: 1px solid var(--text-muted); box-shadow: none; width: auto; padding: 10px 30px; }
        
        #camera-container { position: relative; width: 100%; max-width: 400px; margin: 0 auto 20px; border-radius: 50%; overflow: hidden; border: 4px solid var(--primary); box-shadow: 0 0 20px rgba(127,0,255,0.3); }
        video { width: 100%; transform: scaleX(-1); display: block; }

        .gallery { column-count: 3; column-gap: 15px; text-align: left; }
        .photo-item { break-inside: avoid; margin-bottom: 15px; border-radius: 12px; overflow: hidden; position: relative; background: #1a1a25; box-shadow: 0 5px 15px rgba(0,0,0,0.3); transition: 0.3s; }
        .photo-item:hover { transform: scale(1.02); }
        .photo-item img { width: 100%; height: auto; display: block; }
        .overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; opacity: 0; transition: 0.3s; }
        .photo-item:hover .overlay { opacity: 1; }

        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.1); text-align: center; }
        .alert.error { background: rgba(255, 71, 87, 0.2); border-color: rgba(255, 71, 87, 0.3); }
        .alert.success { background: rgba(46, 213, 115, 0.2); border-color: rgba(46, 213, 115, 0.3); }

        @media (max-width: 768px) { .gallery { column-count: 2; } .container { padding: 10px; } }
    </style>
</head>
<body>
<nav>
    <div class="nav-brand" onclick="window.location.href='/'">SnapMatch Pro</div>
    <div class="nav-links">
        {% if session.get('user_id') %}
            <a href="/dashboard">Dashboard</a>
            <a href="/profile">My Profile</a>
            <a href="/logout" style="color: #ff6b6b;">Logout</a>
        {% else %}
            <a href="/login">Login</a>
            <a href="/register">Register</a>
        {% endif %}
    </div>
</nav>
<div class="container">
    {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
                <div class="alert {{ category }}">{{ message }}</div>
            {% endfor %}
        {% endif %}
    {% endwith %}

    {% if view == 'verify' %}
    <div class="card" style="max-width: 500px; margin: 50px auto; text-align: center;">
        <div style="font-size: 3rem; margin-bottom: 20px;">📧</div>
        <h2>Verifying...</h2>
        <p class="tagline">Please wait while we verify your account.</p>
    </div>
    {% endif %}

    {% if view == 'login' %}
    <div class="card" style="max-width: 400px; margin: 50px auto;">
        <h2 style="text-align: center;">Welcome Back</h2>
        <p class="tagline" style="text-align: center;">Login with Username or Email.</p>
        <form method="post">
            <input type="text" name="login" placeholder="Username or Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Login</button>
        </form>
        <div style="text-align: center; margin-top: 20px; color: var(--text-muted);">
            Don't have an account? <a href="/register" style="color: var(--primary);">Register</a>
        </div>
    </div>
    {% endif %}

    {% if view == 'register' %}
    <div class="card" style="max-width: 400px; margin: 50px auto;">
        <h2 style="text-align: center;">Create Account</h2>
        <p class="tagline" style="text-align: center;">Join the event.</p>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Register</button>
        </form>
        <div style="text-align: center; margin-top: 20px; color: var(--text-muted);">
            Already have an account? <a href="/login" style="color: var(--primary);">Login</a>
        </div>
    </div>
    {% endif %}

    {% if view == 'dashboard' %}
    <div class="card">
        <h2>📂 Upload Photos</h2>
        <p class="tagline">Upload event photos. AI detects all faces.</p>
        <form method="post" action="/upload" enctype="multipart/form-data" id="uploadForm">
            <input type="file" name="photos" multiple accept="image/*" required id="fileInput">
            <button type="submit" class="btn" id="uploadBtn">Upload & Process</button>
        </form>
    </div>
    <div class="card" style="text-align: center;">
        <h2>🔍 Find My Photos</h2>
        <p class="tagline">Take a selfie. We match against every face.</p>
        <div id="camera-container">
            <video id="video" autoplay playsinline muted></video>
        </div>
        <button id="scanBtn" class="btn">📸 Capture & Match</button>
    </div>
    {% endif %}

    {% if view == 'results' %}
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>🎉 Your Photos ({{ photos|length }})</h2>
            <div style="display: flex; gap: 10px;">
                <a href="/download-all" class="btn btn-success btn-outline">Download All (ZIP)</a>
                <a href="/dashboard" class="btn btn-outline">Back</a>
            </div>
        </div>
        {% if photos|length == 0 %}
            <p style="text-align: center; padding: 40px; color: var(--text-muted);">No matches found.</p>
        {% else %}
        <div class="gallery">
            {% for p in photos %}
            <div class="photo-item">
                <img src="/uploads/{{ p.filename }}" loading="lazy">
                <div class="overlay">
                    <a href="/uploads/{{ p.filename }}" download class="btn btn-sm">Download</a>
                </div>
            </div>
            {% endfor %}
        </div>
        {% endif %}
    </div>
    {% endif %}

    {% if view == 'profile' %}
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>My Uploads</h2>
            <form action="/delete-all" method="post" onsubmit="return confirm('Delete all?');">
                <button type="submit" class="btn btn-danger-outline">Delete All</button>
            </form>
        </div>
        {% if my_photos|length == 0 %}
            <p style="text-align: center;">No uploads yet.</p>
            <div style="text-align: center;"><a href="/dashboard" class="btn btn-outline">Go to Dashboard</a></div>
        {% else %}
        <div class="gallery">
            {% for p in my_photos %}
            <div class="photo-item">
                <img src="/uploads/{{ p.filename }}">
                <div class="overlay" style="display: flex; flex-direction: column; gap: 5px;">
                    <form action="/delete-photo/{{ p.id }}" method="post" onsubmit="return confirm('Delete?');">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <a href="/uploads/{{ p.filename }}" download class="btn btn-sm" style="background: white; color: black;">Save</a>
                </div>
            </div>
            {% endfor %}
        </div>
        {% endif %}
    </div>
    {% endif %}

</div>
<script>
    const fileInput = document.getElementById('fileInput');
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadForm = document.getElementById('uploadForm');
    if(uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            if(fileInput.files.length > 50) { e.preventDefault(); alert("Max 50 files."); }
            else { uploadBtn.textContent = "Uploading..."; uploadBtn.disabled = true; }
        });
    }
    const video = document.getElementById('video');
    const scanBtn = document.getElementById('scanBtn');
    if(video) {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } })
            .then(stream => video.srcObject = stream)
            .catch(err => console.error(err));
        if(scanBtn) {
            scanBtn.addEventListener('click', () => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0);
                canvas.toBlob(blob => {
                    const formData = new FormData();
                    formData.append('selfie', blob);
                    scanBtn.textContent = "Scanning...";
                    scanBtn.disabled = true;
                    fetch('/scan', { method: 'POST', body: formData })
                    .then(r => r.json())
                    .then(data => {
                        if(data.success) window.location.href = '/results';
                        else { alert(data.message); location.reload(); }
                    });
                }, 'image/jpeg');
            });
        }
    }
</script>
</body>
</html>
"""

# ==========================================
# ROUTES
# ==========================================

@app.route('/')
def index():
    if 'user_id' in session: return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if not username or not email or not password:
            flash("All fields required.", "error")
            return redirect(url_for('register'))
            
        pw_hash = generate_password_hash(password)
        verification_token = str(uuid.uuid4())
        
        conn = get_db_connection()
        try:
            conn.execute("INSERT INTO users (username, email, password, verification_token) VALUES (?, ?, ?, ?)", 
                       (username, email, pw_hash, verification_token))
            conn.commit()
            
            # Send Email (or print to console)
            send_verification_email(email, username, verification_token)
            
            flash("Account created! Please check your email (or terminal) to verify.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username or Email already exists.", "error")
        finally:
            conn.close()
            
    return render_template_string(HTML_TEMPLATE, view='register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_input = request.form['login'] # Could be username or email
        password = request.form['password']
        
        conn = get_db_connection()
        # Query by username OR email
        user = conn.execute("SELECT * FROM users WHERE username = ? OR email = ?", (login_input, login_input)).fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            if user['is_verified'] == 0:
                # If user registered but didn't verify, send email again
                send_verification_email(user['email'], user['username'], user['verification_token'])
                flash("Account not verified. Verification link sent again.", "error")
                return redirect(url_for('login'))
            
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials.", "error")
            
    return render_template_string(HTML_TEMPLATE, view='login')

@app.route('/verify/<token>')
def verify_account(token):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE verification_token = ?", (token,)).fetchone()
    
    if user:
        conn.execute("UPDATE users SET is_verified = 1, verification_token = NULL WHERE id = ?", (user['id'],))
        conn.commit()
        conn.close()
        flash("Email verified! You can now login.", "success")
        return redirect(url_for('login'))
    else:
        flash("Invalid or expired verification link.", "error")
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template_string(HTML_TEMPLATE, view='dashboard')

@app.route('/profile')
@login_required
def profile():
    conn = get_db_connection()
    photos = conn.execute("SELECT * FROM photos WHERE user_id = ? ORDER BY created_at DESC", (session['user_id'],)).fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='profile', my_photos=photos)

@app.route('/upload', methods=['POST'])
@login_required
def upload():
    files = request.files.getlist('photos')
    conn = get_db_connection()
    count = 0
    if len(files) > 50:
        flash("Too many files. Max 50.", "error")
        return redirect(url_for('dashboard'))

    for file in files:
        if file.filename:
            filename = f"{uuid.uuid4()}_{secure_filename(file.filename)}"
            path = optimize_and_save_image(file, UPLOAD_FOLDER, filename)
            if path:
                embs = get_embedding(path)
                conn.execute("INSERT INTO photos (filename, user_id, embeddings_json) VALUES (?, ?, ?)",
                             (filename, session['user_id'], json.dumps(embs) if embs else None))
                count += 1
    
    conn.commit()
    conn.close()
    flash(f"Uploaded {count} photos.", "success")
    return redirect(url_for('dashboard'))

@app.route('/uploads/<filename>')
def serve_upload(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/delete-photo/<int:pid>', methods=['POST'])
@login_required
def delete_photo(pid):
    conn = get_db_connection()
    photo = conn.execute("SELECT * FROM photos WHERE id = ?", (pid,)).fetchone()
    if photo and photo['user_id'] == session['user_id']:
        conn.execute("DELETE FROM photos WHERE id = ?", (pid,))
        conn.commit()
        try: os.remove(os.path.join(UPLOAD_FOLDER, photo['filename']))
        except: pass
        flash("Photo deleted.", "success")
    conn.close()
    return redirect(url_for('profile'))

@app.route('/delete-all', methods=['POST'])
@login_required
def delete_all_photos():
    user_id = session['user_id']
    conn = get_db_connection()
    photos = conn.execute("SELECT filename FROM photos WHERE user_id = ?", (user_id,)).fetchall()
    count = 0
    for p in photos:
        try:
            os.remove(os.path.join(UPLOAD_FOLDER, p['filename']))
            count += 1
        except: pass
    conn.execute("DELETE FROM photos WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    flash(f"Deleted {count} uploads.", "success")
    return redirect(url_for('profile'))

@app.route('/scan', methods=['POST'])
@login_required
def scan():
    if 'selfie' not in request.files: return jsonify({'success': False, 'message': 'No selfie'})
    
    selfie = request.files['selfie']
    path = os.path.join(SELFIES_FOLDER, f"{session['user_id']}_scan.jpg")
    selfie.save(path)
    
    selfie_embs = get_embedding(path)
    if not selfie_embs: return jsonify({'success': False, 'message': 'No face detected'})
    
    user_emb = selfie_embs[0]
    
    conn = get_db_connection()
    photos = conn.execute("SELECT id, embeddings_json FROM photos WHERE embeddings_json IS NOT NULL").fetchall()
    matched_ids = []
    
    if DEBUG_MODE: print(f"\n[DEBUG] Comparing User {session['user_id']} against {len(photos)} photos. Threshold: {DISTANCE_THRESHOLD}\n")

    for p in photos:
        photo_embs_list = json.loads(p['embeddings_json'])
        is_match = False
        for face_vec in photo_embs_list:
            dist = calculate_cosine_distance(user_emb, face_vec)
            if DEBUG_MODE: print(f"Photo ID {p['id']}: Distance = {dist:.4f}")
            if dist < DISTANCE_THRESHOLD:
                is_match = True
                break
        if is_match:
            matched_ids.append(p['id'])
    
    if DEBUG_MODE: print(f"\n[DEBUG] Total Matches: {len(matched_ids)}\n")
    
    session['matched_photos'] = matched_ids
    conn.close()
    return jsonify({'success': True})

@app.route('/results')
@login_required
def results():
    if 'matched_photos' not in session: return redirect(url_for('dashboard'))
    matched_ids = session['matched_photos']
    
    conn = get_db_connection()
    placeholders = ','.join('?' for _ in matched_ids)
    photos = conn.execute(f"SELECT * FROM photos WHERE id IN ({placeholders})", matched_ids).fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='results', photos=photos)

@app.route('/download-all')
@login_required
def download_all():
    if 'matched_photos' not in session: return "No session", 400
    matched_ids = session['matched_photos']
    conn = get_db_connection()
    placeholders = ','.join('?' for _ in matched_ids)
    photos = conn.execute(f"SELECT * FROM photos WHERE id IN ({placeholders})", matched_ids).fetchall()
    
    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for p in photos:
            path = os.path.join(UPLOAD_FOLDER, p['filename'])
            if os.path.exists(path): zf.write(path, p['filename'])
    memory_file.seek(0)
    return send_file(memory_file, mimetype='application/zip', as_attachment=True, download_name='snapmatches.zip')

if __name__ == '__main__':
    print("-" * 60)
    print("   SNAPMATCH - EMAIL VERIFICATION SYSTEM")
    print("-" * 60)
    print(f"   Email Mode: {'SMTP Sending' if ENABLE_EMAIL_SENDING else 'CONSOLE LOGGING'}")
    print("-" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)