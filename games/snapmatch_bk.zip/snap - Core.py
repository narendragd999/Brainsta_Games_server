import os
import uuid
import sqlite3
import json
import cv2
import numpy as np
import smtplib
import threading
import time
import qrcode
import zipfile
from io import BytesIO
from datetime import datetime, timedelta
from email.mime.text import MIMEText

from flask import (
    Flask, render_template_string, request, jsonify,
    send_from_directory, redirect, url_for,
    session, flash, send_file
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename, safe_join
from PIL import Image

# ==========================================
# CONFIGURATION
# ==========================================
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

# Standard Uploads (For "Upload Mode")
MEDIA_FOLDER = os.path.join(APP_ROOT, 'snapmatch_uploads')
SELFIES_FOLDER = os.path.join(APP_ROOT, 'snapmatch_selfies')
QR_FOLDER = os.path.join(APP_ROOT, 'static_qr') 
DATABASE = os.path.join(APP_ROOT, 'snap_dir_mode.db')

# AI SETTINGS
DISTANCE_THRESHOLD = 0.70
MODEL_NAME = 'ArcFace' 
DEBUG_MODE = True

# PAYMENT SETTINGS
UPI_ID = "veer@upi" 
PAYMENT_NOTE = "SnapMatch Event Access"

# EMAIL SETTINGS
ENABLE_EMAIL_SENDING = False
MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
MAIL_PORT = 587
MAIL_USERNAME = os.getenv('MAIL_USERNAME', 'your_email@gmail.com')
MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', 'your_password')

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024 * 1024 * 2  # 2GB
app.secret_key = os.getenv('SECRET_KEY', 'super_secret_dir_mode')

# Ensure folders exist
for folder in [MEDIA_FOLDER, SELFIES_FOLDER, QR_FOLDER]:
    os.makedirs(folder, exist_ok=True)

print(f"[CONFIG] Media Folder: {os.path.abspath(MEDIA_FOLDER)}")

# ==========================================
# DATABASE SCHEMA
# ==========================================
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE NOT NULL,
                 email TEXT UNIQUE NOT NULL,
                 password TEXT NOT NULL,
                 is_verified INTEGER DEFAULT 0,
                 is_admin INTEGER DEFAULT 0,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    c.execute('''CREATE TABLE IF NOT EXISTS events (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 user_id INTEGER NOT NULL,
                 share_token TEXT UNIQUE NOT NULL,
                 keep_days INTEGER NOT NULL,
                 is_paid INTEGER DEFAULT 0,
                 payment_amount REAL DEFAULT 0.0,
                 source_type TEXT DEFAULT 'upload', 
                 source_path TEXT,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY(user_id) REFERENCES users(id))''')
    
    c.execute("CREATE INDEX IF NOT EXISTS idx_events_user ON events(user_id)")

    c.execute('''CREATE TABLE IF NOT EXISTS media (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 event_id INTEGER NOT NULL,
                 filename TEXT NOT NULL,
                 file_type TEXT NOT NULL,
                 embeddings_json TEXT,
                 expiry_date TIMESTAMP NOT NULL,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE)''')
    
    c.execute("CREATE INDEX IF NOT EXISTS idx_media_expiry ON media(expiry_date)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_media_event ON media(event_id)")

    conn.commit()
    conn.close()
    print("[DB] Database initialized with Directory Mode support.")

# ==========================================
# BACKGROUND WORKER
# ==========================================
def cleanup_worker():
    while True:
        try:
            conn = get_db_connection()
            now = datetime.now()
            # Only cleanup 'upload' type events. Directory events manage themselves.
            expired = conn.execute("SELECT m.id, m.filename FROM media m JOIN events e ON m.event_id = e.id WHERE m.expiry_date < ? AND e.source_type = 'upload'", (now,)).fetchall()
            for item in expired:
                file_path = os.path.join(MEDIA_FOLDER, item['filename'])
                try:
                    if os.path.exists(file_path): os.remove(file_path)
                    conn.execute("DELETE FROM media WHERE id = ?", (item['id'],))
                except: pass
            conn.commit()
            conn.close()
        except: pass
        time.sleep(3600)

threading.Thread(target=cleanup_worker, daemon=True).start()

# ==========================================
# HELPERS
# ==========================================
def generate_upi_qr(amount, note):
    upi_string = f"upi://pay?pa={UPI_ID}&pn=SnapMatch&am={amount}&tn={note}"
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(upi_string)
    qr.make(fit=True)
    img = qr.make_image(fill='black', back='white')
    filename = f"qr_{uuid.uuid4()}.png"
    img.save(os.path.join(QR_FOLDER, filename))
    return filename

def login_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session: return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

def admin_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session or not session.get('is_admin'):
            flash("Admin access only.", "error")
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# ==========================================
# PROFESSIONAL HTML TEMPLATE
# ==========================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SnapMatch | Local Directory Mode</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4F46E5; --primary-hover: #4338ca;
            --secondary: #10B981;
            --bg-body: #F3F4F6; --surface: #ffffff;
            --text-main: #111827; --text-muted: #6B7280; --danger: #EF4444;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --radius: 16px;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-body); color: var(--text-main); min-height: 100vh; display: flex; flex-direction: column; }
        
        nav { background: var(--surface); padding: 1rem 2rem; box-shadow: var(--shadow-sm); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
        .logo { font-weight: 700; font-size: 1.5rem; color: var(--primary); text-decoration: none; }
        .nav-links { display: flex; gap: 1.5rem; }
        .nav-links a { text-decoration: none; color: var(--text-muted); font-weight: 500; font-size: 0.95rem; transition: color 0.2s; }
        .nav-links a:hover { color: var(--primary); }

        .container { max-width: 1100px; margin: 0 auto; padding: 2rem 1rem; width: 100%; flex: 1; }

        .card { background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow-md); padding: 2rem; margin-bottom: 2rem; border: 1px solid rgba(0,0,0,0.02); }
        h2 { font-size: 1.875rem; font-weight: 700; margin-bottom: 0.5rem; color: var(--text-main); }
        p.subtitle { color: var(--text-muted); margin-bottom: 2rem; line-height: 1.6; }

        .input-group { margin-bottom: 1.5rem; }
        input, select { width: 100%; padding: 0.875rem 1rem; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 1rem; font-family: inherit; transition: border-color 0.2s; background: #F9FAFB; }
        input:focus, select:focus { outline: none; border-color: var(--primary); background: white; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; font-size: 0.95rem; text-decoration: none; cursor: pointer; transition: all 0.2s; border: none; font-family: inherit; }
        .btn-primary { background: var(--primary); color: white; box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.3); }
        .btn-primary:hover { background: var(--primary-hover); transform: translateY(-1px); }
        .btn-outline { background: transparent; border: 2px solid var(--primary); color: var(--primary); }
        .btn-full { width: 100%; }

        /* Toggle Switch for Source Type */
        .toggle-container { display: flex; background: #F3F4F6; padding: 4px; border-radius: 8px; margin-bottom: 1.5rem; }
        .toggle-btn { flex: 1; padding: 10px; text-align: center; border-radius: 6px; cursor: pointer; font-weight: 500; color: var(--text-muted); transition: 0.3s; }
        .toggle-btn.active { background: white; color: var(--primary); shadow: var(--shadow-sm); font-weight: 700; }
        
        .hidden { display: none; }
        
        /* Table */
        .table-container { overflow-x: auto; border: 1px solid #E5E7EB; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid #E5E7EB; }
        th { background: #F9FAFB; font-size: 0.85rem; text-transform: uppercase; color: var(--text-muted); }

        /* Camera & Results */
        .hero-section { text-align: center; max-width: 600px; margin: 0 auto; }
        .camera-wrapper { position: relative; width: 280px; height: 280px; margin: 2rem auto; border-radius: 50%; overflow: hidden; border: 4px solid white; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1); background: #000; }
        video { width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); }
        .btn-snap { width: 72px; height: 72px; border-radius: 50%; background: white; border: 4px solid var(--primary); position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); cursor: pointer; }
        .btn-snap:active { transform: translateX(-50%) scale(0.95); }
        
        .gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1.5rem; margin-top: 2rem; }
        .photo-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: var(--shadow-sm); transition: transform 0.3s; }
        .photo-card:hover { transform: translateY(-5px); box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); }
        .photo-card img { width: 100%; height: 220px; object-fit: cover; display: block; }
        .photo-actions { padding: 1rem; display: flex; justify-content: space-between; align-items: center; background: white; border-top: 1px solid #F3F4F6; }
        .photo-actions a { text-decoration: none; color: var(--primary); font-weight: 600; }

        .alert { padding: 1rem 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; display: flex; align-items: center; font-weight: 500; }
        .alert-success { background: #ECFDF5; color: #065F46; border: 1px solid #A7F3D0; }
        .alert-error { background: #FEF2F2; color: #991B1B; border: 1px solid #FECACA; }
        
        .download-all-container { margin-top: 1rem; text-align: center; display: none; }
        .download-all-container.show { display: block; animation: slideDown 0.5s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

    </style>
</head>
<body>

<nav>
    <a href="/" class="logo">SnapMatch</a>
    <div class="nav-links">
        {% if session.get('user_id') %}
            <a href="/dashboard">Dashboard</a>
            <a href="/events">My Events</a>
            {% if session.get('is_admin') %}<a href="/admin/users">Admin</a>{% endif %}
            <a href="/logout" style="color: var(--danger)">Logout</a>
        {% else %}
            <a href="/login">Login</a>
            <a href="/register" style="color: var(--primary); font-weight: 700;">Get Started</a>
        {% endif %}
    </div>
</nav>

<div class="container">
    {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
                <div class="alert alert-{{ 'error' if category == 'error' else 'success' }}">{{ message }}</div>
            {% endfor %}
        {% endif %}
    {% endwith %}

    <!-- LOGIN -->
    {% if view == 'login' %}
    <div class="card" style="max-width: 420px; margin: 3rem auto;">
        <h2 style="text-align:center;">Welcome Back</h2>
        <p class="subtitle" style="text-align:center;">Access your events</p>
        <form method="post">
            <div class="input-group"><input type="text" name="login" placeholder="Username or Email" required></div>
            <div class="input-group"><input type="password" name="password" placeholder="Password" required></div>
            <button type="submit" class="btn btn-primary btn-full">Login</button>
            <p style="text-align:center; margin-top:1.5rem; font-size:0.9rem;"><a href="/register" style="color:var(--primary)">Register</a></p>
        </form>
    </div>
    {% endif %}

    <!-- REGISTER -->
    {% if view == 'register' %}
    <div class="card" style="max-width: 420px; margin: 3rem auto;">
        <h2 style="text-align:center;">Create Account</h2>
        <form method="post">
            <div class="input-group"><input type="text" name="username" placeholder="Username" required></div>
            <div class="input-group"><input type="email" name="email" placeholder="Email" required></div>
            <div class="input-group"><input type="password" name="password" placeholder="Password" required></div>
            <button type="submit" class="btn btn-primary btn-full">Create Account</button>
        </form>
    </div>
    {% endif %}

    <!-- DASHBOARD -->
    {% if view == 'dashboard' %}
    <div class="card">
        <h2>Hello, {{ session.username }} 👋</h2>
        <p class="subtitle">Manage your photography events. Choose to upload files or link a local server directory.</p>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
            <a href="/events/create" class="card" style="text-align:center; padding: 1.5rem; text-decoration:none; color:inherit; border: 1px dashed var(--primary); background: #EEF2FF;">
                <div style="font-size:2rem; margin-bottom:0.5rem;">+</div>
                <div style="font-weight:600;">Create New Event</div>
            </a>
            <a href="/events" class="card" style="text-align:center; padding: 1.5rem; text-decoration:none; color:inherit; border: 1px solid #E5E7EB;">
                <div style="font-size:2rem; margin-bottom:0.5rem;">📂</div>
                <div style="font-weight:600;">My Events</div>
            </a>
        </div>
    </div>
    {% endif %}

    <!-- EVENTS LIST -->
    {% if view == 'events' %}
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem;">
        <h2>My Events</h2>
        <a href="/events/create" class="btn btn-primary">+ Create Event</a>
    </div>
    <div class="card" style="padding:0;">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th style="text-align:right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {% for e in events %}
                    <tr>
                        <td>
                            <div style="font-weight:600;">{{ e.name }}</div>
                            <div style="font-size:0.8rem; color:var(--text-muted)">{{ e.share_token }}</div>
                        </td>
                        <td>
                            <span style="font-size:0.8rem; padding: 2px 8px; border-radius:4px; background:{{ '#E0E7FF' if e.source_type == 'directory' else '#F3F4F6' }}; color:var(--text-muted);">
                                {{ '📁 Local Dir' if e.source_type == 'directory' else '☁️ Upload' }}
                            </span>
                        </td>
                        <td>
                            {% if e.is_paid %}
                                <span class="btn-outline" style="font-size:0.75rem; padding: 2px 8px; border-color:#10B981; color:#10B981;">Active</span>
                            {% else %}
                                <span class="btn-outline" style="font-size:0.75rem; padding: 2px 8px; border-color:#EF4444; color:#EF4444;">Unpaid</span>
                            {% endif %}
                        </td>
                        <td style="text-align:right">
                            {% if e.is_paid %}
                                {% if e.source_type == 'upload' %}
                                    <a href="/event/{{ e.id }}/upload" class="btn btn-outline" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Upload</a>
                                {% else %}
                                    <span style="font-size:0.8rem; color:var(--text-muted); margin-right:10px;">Ready</span>
                                {% endif %}
                            {% else %}
                                <a href="/event/{{ e.id }}/pay" class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Pay ₹{{ e.payment_amount }}</a>
                            {% endif %}
                            <a href="/share/{{ e.share_token }}" target="_blank" class="btn btn-outline" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">Share</a>
                            <form action="/event/{{ e.id }}/delete" method="post" onsubmit="return confirm('Delete?');" style="display:inline;">
                                <button class="btn btn-danger" style="padding: 0.4rem 0.8rem; font-size: 0.8rem;">X</button>
                            </form>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
    </div>
    {% endif %}

    <!-- CREATE EVENT (UPDATED FOR DIRECTORY) -->
    {% if view == 'create_event' %}
    <div class="card" style="max-width: 500px; margin: 0 auto;">
        <h2>Create Event</h2>
        <p class="subtitle">Choose how you want to provide photos.</p>
        <form method="post">
            
            <!-- TOGGLE -->
            <div class="toggle-container">
                <div class="toggle-btn active" onclick="setSourceType('upload', this)">Upload Files</div>
                <div class="toggle-btn" onclick="setSourceType('directory', this)">Local Directory</div>
            </div>
            <input type="hidden" name="source_type" id="source_type" value="upload">

            <!-- FIELDS -->
            <div class="input-group">
                <label style="display:block; margin-bottom:0.5rem; font-weight:600; font-size:0.9rem;">Event Name</label>
                <input type="text" name="name" placeholder="e.g. Wedding 2024" required>
            </div>

            <!-- DIRECTORY INPUT -->
            <div class="input-group hidden" id="dir_input_group">
                <label style="display:block; margin-bottom:0.5rem; font-weight:600; font-size:0.9rem;">Server Absolute Path</label>
                <input type="text" name="source_path" id="source_path_input" placeholder="e.g. C:\\Photos\\Wedding or /home/user/pics">
                <small style="color:var(--text-muted); font-size:0.8rem;">Must be a folder on the machine running this server.</small>
            </div>

            <div class="input-group">
                <label style="display:block; margin-bottom:0.5rem; font-weight:600; font-size:0.9rem;">Retention Period</label>
                <select name="keep_days" required onchange="updatePrice()">
                    <option value="1">1 Day (Free)</option>
                    <option value="2">2 Days (Free)</option>
                    <option value="3">3 Days (Free)</option>
                    <option value="7">7 Days (₹99)</option>
                    <option value="30">30 Days (₹299)</option>
                </select>
            </div>
            
            <div id="priceBox" style="background: #F3F4F6; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; text-align:center; font-weight:700; color: var(--primary);">
                Total: Free
            </div>
            <button type="submit" class="btn btn-primary btn-full">Create Event</button>
        </form>
    </div>
    <script>
        function setSourceType(type, btn) {
            document.getElementById('source_type').value = type;
            document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const dirGroup = document.getElementById('dir_input_group');
            const dirInput = document.getElementById('source_path_input');
            
            if(type === 'directory') {
                dirGroup.classList.remove('hidden');
                dirInput.setAttribute('required', 'true');
            } else {
                dirGroup.classList.add('hidden');
                dirInput.removeAttribute('required');
                dirInput.value = '';
            }
        }
        function updatePrice(){
            const val = document.querySelector('select[name="keep_days"]').value;
            const cost = val > 3 ? (val == 7 ? 99 : 299) : 0;
            document.getElementById('priceBox').innerText = cost > 0 ? `Total: ₹${cost}` : "Total: Free";
        }
    </script>
    {% endif %}

    <!-- UPLOAD (Only for Upload Type) -->
    {% if view == 'upload' %}
    <div class="card">
        <h2>Upload Media</h2>
        <p class="subtitle">Event: <strong>{{ event.name }}</strong></p>
        <form method="post" enctype="multipart/form-data">
            <div class="input-group">
                <label style="display:block; margin-bottom:0.5rem;">Select Files</label>
                <input type="file" name="media" multiple required>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Start Upload</button>
        </form>
    </div>
    {% endif %}

    <!-- PAYMENT -->
    {% if view == 'payment' %}
    <div class="card" style="max-width:400px; margin:0 auto; text-align:center;">
        <h2>Secure Payment</h2>
        <p>Scan to pay <strong>₹{{ event.payment_amount }}</strong></p>
        <img src="/static_qr/{{ qr_file }}" style="width:200px; margin: 20px 0; border-radius:8px;">
        <p>UPI: {{ UPI_ID }}</p>
        <form method="post" style="margin-top:20px;">
            <button type="submit" class="btn btn-primary btn-full">Confirm Payment</button>
        </form>
    </div>
    {% endif %}

    <!-- PUBLIC SHARE -->
    {% if view == 'share' %}
    <div class="hero-section">
        <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem;">Find Your Photos</h1>
        <p class="subtitle">Take a selfie to find your photos in <strong>{{ event.name }}</strong>.</p>
        
        <div class="camera-wrapper">
            <video id="video" autoplay playsinline muted></video>
            <div class="btn-snap" onclick="snapAndMatch()"></div>
        </div>
        
        <div id="status" style="min-height:24px; font-weight:600; color:var(--text-muted); margin-top:1rem;"></div>

        <div id="downloadAllContainer" class="download-all-container">
            <button onclick="downloadAll()" class="btn btn-primary" style="padding: 1rem 2rem; font-size: 1.1rem; box-shadow: var(--shadow-md);">
                ⬇️ Download All Photos
            </button>
        </div>

        <div id="results" class="gallery-grid"></div>
    </div>
    <script>
        const video = document.getElementById('video');
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } }).then(s => video.srcObject = s).catch(e => alert("Camera needed"));

        let matchedFiles = [];

        function snapAndMatch() {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth; canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            
            canvas.toBlob(blob => {
                const fd = new FormData(); fd.append('selfie', blob);
                const status = document.getElementById('status');
                status.innerHTML = '<span style="color:var(--primary)">🔍 Scanning Directory... (This may take a moment)</span>';
                
                fetch('/match/{{ token }}', { method: 'POST', body: fd })
                .then(r => r.json())
                .then(d => {
                    const res = document.getElementById('results');
                    const dlBtn = document.getElementById('downloadAllContainer');
                    res.innerHTML = '';
                    matchedFiles = d.matches; 
                    
                    if(d.matches.length > 0) {
                        d.matches.forEach(m => {
                            res.innerHTML += `
                            <div class="photo-card">
                                <img src="/uploads/${m}" loading="lazy">
                                <div class="photo-actions">
                                    <span>HD Photo</span>
                                    <a href="/uploads/${m}" download>Download</a>
                                </div>
                            </div>`;
                        });
                        status.innerHTML = `<span style="color:var(--secondary)">✅ Found ${d.matches.length} photos!</span>`;
                        dlBtn.classList.add('show');
                    } else {
                        status.innerHTML = `<span style="color:var(--danger)">❌ No matches found.</span>`;
                        dlBtn.classList.remove('show');
                    }
                });
            }, 'image/jpeg');
        }

        function downloadAll() {
            if (matchedFiles.length === 0) return;
            const btn = document.querySelector('#downloadAllContainer button');
            btn.innerText = "Zipping..."; btn.disabled = true;
            
            fetch('/download_all', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filenames: matchedFiles, token: '{{ token }}' }) })
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = 'photos.zip'; a.click();
                window.URL.revokeObjectURL(url);
                btn.innerText = "⬇️ Download All Photos"; btn.disabled = false;
            });
        }
    </script>
    {% endif %}

    <!-- ADMIN USERS -->
    {% if view == 'admin_users' %}
    <div class="card"><h2>User Management</h2>... (Admin UI similar to previous) ...</div>
    {% endif %}

    <!-- EDIT USER -->
    {% if view == 'edit_user' %}
    <div class="card" style="max-width:400px; margin:0 auto;"><h2>Edit User</h2>... (Edit UI similar to previous) ...</div>
    {% endif %}

</div>
</body>
</html>
"""

# ==========================================
# ROUTES
# ==========================================

@app.route('/')
def index():
    if 'user_id' in session: return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            h = generate_password_hash(request.form['password'])
            conn = get_db_connection()
            conn.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                         (request.form['username'], request.form['email'], h))
            conn.commit()
            conn.close()
            flash("Account created!", "success")
            return redirect(url_for('login'))
        except: flash("User exists.", "error")
    return render_template_string(HTML_TEMPLATE, view='register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        conn = get_db_connection()
        u = conn.execute("SELECT * FROM users WHERE username=? OR email=?", 
                         (request.form['login'], request.form['login'])).fetchone()
        conn.close()
        if u and check_password_hash(u['password'], request.form['password']):
            session['user_id'] = u['id']
            session['username'] = u['username']
            session['is_admin'] = u['is_admin']
            return redirect(url_for('dashboard'))
        flash("Invalid credentials.", "error")
    return render_template_string(HTML_TEMPLATE, view='login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template_string(HTML_TEMPLATE, view='dashboard')

# --- EVENT MANAGEMENT ---

@app.route('/events')
@login_required
def events():
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE user_id=? ORDER BY id DESC", (session['user_id'],)).fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='events', events=ev)

@app.route('/events/create', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        name = request.form['name']
        days = int(request.form['keep_days'])
        source_type = request.form.get('source_type', 'upload')
        source_path = request.form.get('source_path') if source_type == 'directory' else None
        
        # Validation for Directory
        if source_type == 'directory':
            if not source_path or not os.path.isdir(source_path):
                flash("Invalid directory path. Please enter a valid absolute path on the server.", "error")
                return redirect(url_for('create_event'))

        is_paid = 0
        amount = 0.0
        if days > 3:
            is_paid = 0
            amount = 99.0 if days == 7 else 299.0
        else:
            is_paid = 1
            
        token = str(uuid.uuid4())[:8]
        conn = get_db_connection()
        conn.execute("INSERT INTO events (name, user_id, share_token, keep_days, is_paid, payment_amount, source_type, source_path) VALUES (?,?,?,?,?,?,?,?)",
                     (name, session['user_id'], token, days, is_paid, amount, source_type, source_path))
        conn.commit()
        conn.close()
        flash("Event created!", "success")
        return redirect(url_for('events'))
    return render_template_string(HTML_TEMPLATE, view='create_event')

@app.route('/event/<int:eid>/delete', methods=['POST'])
@login_required
def delete_event(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    if ev and ev['user_id'] == session['user_id']:
        # Only delete files if it was an upload type
        if ev['source_type'] == 'upload':
            media = conn.execute("SELECT filename FROM media WHERE event_id=?", (eid,)).fetchall()
            for m in media:
                try: os.remove(os.path.join(MEDIA_FOLDER, m['filename']))
                except: pass
            conn.execute("DELETE FROM media WHERE event_id=?", (eid,))
        conn.execute("DELETE FROM events WHERE id=?", (eid,))
        conn.commit()
        flash("Event deleted.", "success")
    conn.close()
    return redirect(url_for('events'))

@app.route('/event/<int:eid>/pay', methods=['GET', 'POST'])
@login_required
def pay_event(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    if not ev: return redirect(url_for('events'))
    if request.method == 'POST':
        conn.execute("UPDATE events SET is_paid=1 WHERE id=?", (eid,))
        conn.commit()
        flash("Payment verified!", "success")
        conn.close()
        return redirect(url_for('events'))
    qr_file = generate_upi_qr(ev['payment_amount'], f"Event {ev['id']}")
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='payment', event=ev, qr_file=qr_file, UPI_ID=UPI_ID)

@app.route('/event/<int:eid>/upload', methods=['GET', 'POST'])
@login_required
def upload_media(eid):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE id=?", (eid,)).fetchone()
    
    # Security check
    if not ev or ev['user_id'] != session['user_id'] or ev['is_paid'] == 0 or ev['source_type'] != 'upload':
        conn.close()
        return redirect(url_for('events'))

    if request.method == 'POST':
        files = request.files.getlist('media')
        expiry = datetime.now() + timedelta(days=ev['keep_days'])
        count = 0
        
        for f in files:
            if f.filename: 
                fname = f"{uuid.uuid4()}_{secure_filename(f.filename)}"
                path = os.path.join(MEDIA_FOLDER, fname)
                try:
                    f.save(path)
                    conn.execute("INSERT INTO media (event_id, filename, file_type, expiry_date) VALUES (?,?,?,?)",
                                 (eid, fname, 'image', expiry))
                    count += 1
                except Exception as e: print(e)
        
        conn.commit()
        conn.close()
        flash(f"{count} files uploaded!", "success")
        return redirect(url_for('events'))
        
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='upload', event=ev)

# --- PUBLIC SHARING & AI (Directory Logic) ---

@app.route('/share/<token>')
def public_share(token):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE share_token=?", (token,)).fetchone()
    conn.close()
    if not ev: return "Invalid Link", 404
    return render_template_string(HTML_TEMPLATE, view='share', event=ev, token=token)

@app.route('/match/<token>', methods=['POST'])
def match_photos(token):
    conn = get_db_connection()
    ev = conn.execute("SELECT * FROM events WHERE share_token=?", (token,)).fetchone()
    if not ev: 
        conn.close()
        return jsonify(matches=[])
    
    # 1. Process Selfie
    selfie = request.files['selfie']
    tmp_path = os.path.join(SELFIES_FOLDER, f"temp_{uuid.uuid4()}.jpg")
    selfie.save(tmp_path)
    
    target_embedding = None
    try:
        from deepface import DeepFace
        selfie_objs = DeepFace.represent(img_path=tmp_path, model_name=MODEL_NAME, enforce_detection=False)
        if not selfie_objs: 
            if os.path.exists(tmp_path): os.remove(tmp_path)
            conn.close()
            return jsonify(matches=[])
        target_embedding = selfie_objs[0]["embedding"]
    except Exception as e:
        print(f"[AI] Error: {e}")
        if os.path.exists(tmp_path): os.remove(tmp_path)
        conn.close()
        return jsonify(matches=[])
    finally:
        if os.path.exists(tmp_path): os.remove(tmp_path)

    matches = []

    # 2. SCENARIO A: UPLOAD MODE (Standard DB Lookup)
    if ev['source_type'] == 'upload':
        media = conn.execute("SELECT id, filename, embeddings_json FROM media WHERE event_id=?", (ev['id'],)).fetchall()
        
        for m in media:
            embeddings = []
            if m['embeddings_json']:
                embeddings = json.loads(m['embeddings_json'])
            else:
                # Lazy load
                try:
                    file_path = os.path.join(MEDIA_FOLDER, m['filename'])
                    objs = DeepFace.represent(img_path=file_path, model_name=MODEL_NAME, enforce_detection=False)
                    new_embeddings = [o["embedding"] for o in objs]
                    conn.execute("UPDATE media SET embeddings_json=? WHERE id=?", (json.dumps(new_embeddings), m['id']))
                    conn.commit()
                    embeddings = new_embeddings
                except: continue

            for emb in embeddings:
                dot = np.dot(target_embedding, emb)
                norm = np.linalg.norm(target_embedding) * np.linalg.norm(emb)
                similarity = dot / norm if norm > 0 else 0
                if (1 - similarity) < DISTANCE_THRESHOLD:
                    if m['filename'] not in matches: matches.append(m['filename'])
                    break

    # 3. SCENARIO B: DIRECTORY MODE (On-The-Fly Scan)
    elif ev['source_type'] == 'directory':
        dir_path = ev['source_path']
        if os.path.exists(dir_path):
            # Supported extensions
            valid_exts = ('.jpg', '.jpeg', '.png', '.webp')
            try:
                files = [f for f in os.listdir(dir_path) if f.lower().endswith(valid_exts)]
                
                for filename in files:
                    file_path = os.path.join(dir_path, filename)
                    try:
                        # Process directly from directory
                        objs = DeepFace.represent(img_path=file_path, model_name=MODEL_NAME, enforce_detection=False)
                        for obj in objs:
                            emb = obj["embedding"]
                            dot = np.dot(target_embedding, emb)
                            norm = np.linalg.norm(target_embedding) * np.linalg.norm(emb)
                            similarity = dot / norm if norm > 0 else 0
                            
                            if (1 - similarity) < DISTANCE_THRESHOLD:
                                matches.append(filename)
                                break # Match found for this file
                    except Exception as e:
                        print(f"[Dir Scan] Skipping {filename}: {e}")
                        continue
            except Exception as e:
                print(f"[Dir Scan] Error reading directory: {e}")

    conn.close()
    return jsonify(matches=matches)

# --- DYNAMIC FILE SERVING ---
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    # 1. Check if it's a standard upload
    std_path = os.path.join(MEDIA_FOLDER, filename)
    if os.path.exists(std_path):
        return send_from_directory(MEDIA_FOLDER, filename)
    
    # 2. Check if it's a directory file (Reverse lookup via Token query param if passed, or just try to find it in active events)
    # For simplicity in this demo, we assume the filename is unique enough or we iterate events.
    # Better approach: The frontend sends a query param ?token=X identifying the event.
    token = request.args.get('token')
    if token:
        conn = get_db_connection()
        ev = conn.execute("SELECT * FROM events WHERE share_token=?", (token,)).fetchone()
        conn.close()
        if ev and ev['source_type'] == 'directory' and ev['source_path']:
            dir_path = os.path.join(ev['source_path'], filename)
            if os.path.exists(dir_path):
                return send_from_directory(ev['source_path'], filename)
    
    return "File not found", 404

# --- DOWNLOAD ALL ---
@app.route('/download_all', methods=['POST'])
def download_all():
    data = request.json
    filenames = data.get('filenames', [])
    token = data.get('token') # Needed to locate directory path
    
    if not filenames: return jsonify({"error": "No files"}), 400

    memory_file = BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Identify source type based on token
        conn = get_db_connection()
        ev = conn.execute("SELECT * FROM events WHERE share_token=?", (token,)).fetchone()
        conn.close()
        
        source_base = MEDIA_FOLDER
        if ev and ev['source_type'] == 'directory':
            source_base = ev['source_path']

        for filename in filenames:
            file_path = os.path.join(source_base, filename)
            if os.path.exists(file_path):
                zf.write(file_path, filename)
    
    memory_file.seek(0)
    return send_file(memory_file, mimetype='application/zip', as_attachment=True, download_name='photos.zip')

# --- USER ADMIN (Simplified for space) ---
@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    conn = get_db_connection()
    users = conn.execute("SELECT * FROM users").fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='admin_users', users=users)

@app.route('/admin/users/add', methods=['POST'])
@login_required
@admin_required
def add_user():
    try:
        h = generate_password_hash(request.form['password'])
        conn = get_db_connection()
        conn.execute("INSERT INTO users (username, email, password) VALUES (?,?,?)",
                     (request.form['username'], request.form['email'], h))
        conn.commit()
        conn.close()
    except: pass
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:uid>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(uid):
    if uid == session['user_id']: return redirect(url_for('admin_users'))
    conn = get_db_connection()
    conn.execute("DELETE FROM users WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:uid>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(uid):
    conn = get_db_connection()
    u = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if request.method == 'POST':
        pwd = request.form['password']
        update_q = "UPDATE users SET username=?, email=?, is_admin=?"
        params = [request.form['username'], request.form['email'], int(request.form['is_admin'])]
        if pwd:
            update_q += ", password=?"
            params.append(generate_password_hash(pwd))
        params.append(uid)
        conn.execute(update_q + " WHERE id=?", params)
        conn.commit()
        conn.close()
        return redirect(url_for('admin_users'))
    conn.close()
    return render_template_string(HTML_TEMPLATE, view='edit_user', user=u)

@app.route('/static_qr/<filename>')
def qr_file(filename):
    return send_from_directory(QR_FOLDER, filename)

if __name__ == '__main__':
    init_db()
    conn = get_db_connection()
    admin = conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
    if not admin:
        conn.execute("INSERT INTO users (username, email, password, is_admin) VALUES (?,?,?,1)",
                     ('admin', 'admin@snap.com', generate_password_hash('admin')))
        conn.commit()
        print("[INIT] Created admin: admin / admin")
    conn.close()
    
    print("[SERVER] Running on http://127.0.0.1:5000")
    print("[INFO] Directory Mode Enabled. You can link server-side folders now.")
    app.run(host='0.0.0.0', port=5000, debug=True)